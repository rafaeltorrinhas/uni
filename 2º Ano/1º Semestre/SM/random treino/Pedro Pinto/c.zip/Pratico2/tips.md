sum(0,+inf) x^n = 1/1-x
