function [X] = sinc(x)
    
    X = sin(pi*x)./(pi*x);

end