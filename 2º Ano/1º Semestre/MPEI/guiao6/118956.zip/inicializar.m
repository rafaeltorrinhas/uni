function [BF] = inicializar(n)
% Inicializa o array BF de bits com zeros
% input:    n - tamanho do array
% output:   BF - array de bits

BF = zeros(1,n,"uint8");

end