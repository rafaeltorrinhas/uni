function pk = poisson(k,lambda)

pk=((lambda^k)/factorial(k))*exp(-lambda);  

end