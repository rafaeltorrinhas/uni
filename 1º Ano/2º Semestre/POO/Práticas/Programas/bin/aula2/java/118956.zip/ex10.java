import java.util.Scanner;

public class ex10 {
  public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Introduza números (Introduza o primeiro de novo para terminar):");
      double firstNumber = scanner.nextDouble();
      double max = firstNumber;
      double min = firstNumber;
      double sum = firstNumber;
      int count = 1;
      
      for (double number = scanner.nextDouble(); number != firstNumber; number = scanner.nextDouble()) {
        if (number > max) {
          max = number;
        }
        if (number < min) {
          min = number;
        }
        sum += number;
        count++;
      }

      double average = sum / count;

      System.out.println("Máximo: " + max);
      System.out.println("Mínimo: " + min);
      System.out.println("Média: " + average);
      System.out.println("Números (#): " + count);

      scanner.close();
    }

    
  }
